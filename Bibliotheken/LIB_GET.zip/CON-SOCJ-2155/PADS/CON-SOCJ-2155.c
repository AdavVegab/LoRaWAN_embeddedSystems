*PADS-LIBRARY-SCH-DECALS-V9*

CON-SOCJ-2155    32000 32000 100 10 100 10 4 5 0 3 8
TIMESTAMP 2019.07.02.14.05.12
"Default Font"
"Default Font"
650   50    0 8 100 10 "Default Font"
REF-DES
650   -50   0 8 100 10 "Default Font"
PART-TYPE
650   -150  0 8 100 10 "Default Font"
*
650   -250  0 8 100 10 "Default Font"
*
CLOSED 5 10 0 -1
200   40   
200   -40  
600   -40  
600   40   
200   40   
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   3 10 0 -1
100   -100 
300   -100 
300   -200 
OPEN   4 10 0 -1
100   -200 
400   -200 
500   -100 
600   -200 
CLOSED 4 10 0 -1
300   -200 
280   -140 
320   -140 
300   -200 
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T0     -200  0 0 60    10    0 2 140   10    0 16 PINSHORT
P-530  10    0 2 -70   10    0 2 0
T0     -100  0 0 60    10    0 2 140   10    0 16 PINSHORT
P-530  10    0 2 -70   10    0 2 0


*END*
